package com.apd.qa.testcases;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.apd.qa.apibuilder.PostApiBuilder;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;
import org.json.simple.JSONObject;

public class ApiTest {
	
	 private String restBookingURL="https://restful-booker.herokuapp.com/booking";
		@Test(priority=1)
		public void GetBookingDetailsFromService()
		{
			given()
		   .when()
		   .get(restBookingURL)
		   .then()
		   		.assertThat()
		   		.statusCode(200);
		}
		
		@Test(priority=1)
		public void CreateBookingFromService()
		{
			PostApiBuilder  postApiBuilder= new PostApiBuilder();
			JSONObject jsonObject= new JSONObject(postApiBuilder.newBooking());
			Response response=RestAssured.given()
			.when()
			.headers(postApiBuilder.defaultHeaders())
			.body(jsonObject)
		    .when()
		    .post(restBookingURL);
			Assert.assertEquals(response.statusCode(), 200);
		}

}
