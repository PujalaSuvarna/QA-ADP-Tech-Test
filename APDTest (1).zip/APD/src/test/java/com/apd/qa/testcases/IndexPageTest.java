package com.apd.qa.testcases;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.apd.qa.base.TestBase;
import com.apd.qa.pages.CalculatorPage;
import com.apd.qa.pages.DynamicButtonsPage;
import com.apd.qa.pages.IndexPage;


public class IndexPageTest extends TestBase {
	IndexPage _IndexPage;
	CalculatorPage _CalculatorPage;
	DynamicButtonsPage _DynamicButtonsPage;
	
	
	public IndexPageTest(){
		super();
	}
	
	@BeforeMethod
	public void setUp(){
		initialization();
		_IndexPage = new IndexPage();
		_DynamicButtonsPage=new DynamicButtonsPage();
		_CalculatorPage=new CalculatorPage();
	}
	
	@Test(priority=1)
	public void validateDynamicButtonTest(){
		driver.get(prop.getProperty("url"));		
		_IndexPage.clickOndynamiChallengeFirstLink();
		_DynamicButtonsPage.clickOndynamicButton(Strings.start.name());
		_DynamicButtonsPage.clickOndynamicButton(Strings.One.name());
		_DynamicButtonsPage.clickOndynamicButton(Strings.Two.name());
		_DynamicButtonsPage.clickOndynamicButton(Strings.Three.name());
	   String messageText=_DynamicButtonsPage.GetButtonMessageLabelText();
	   Assert.assertEquals(messageText, "All Buttons Clicked");
	}
	
	@Test(priority=2)
	public void mathCalculationTest(){
		driver.get(prop.getProperty("url"));
		_IndexPage.clickOncalculatorLink();
	   String result=_CalculatorPage.GetResultBasedOnFunction("20","10",Strings.plus.name());
	   Assert.assertEquals(result, "30");
	   
	   result=_CalculatorPage.GetResultBasedOnFunction("20","10",Strings.minus.name());
	   Assert.assertEquals(result, "10");
	   
	   result=_CalculatorPage.GetResultBasedOnFunction("20","10",Strings.times.name());
	   Assert.assertEquals(result, "200");
	   
	   result=_CalculatorPage.GetResultBasedOnFunction("20","10",Strings.divide.name());
	   Assert.assertEquals(result, "2");
	}
	
	@AfterMethod
	public void tearDown(){
		driver.quit();
	}
}

enum Strings {
    One, Two, Three,start,plus,times,minus,divide
}
