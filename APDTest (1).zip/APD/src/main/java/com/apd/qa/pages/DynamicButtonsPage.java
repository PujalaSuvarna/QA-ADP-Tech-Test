package com.apd.qa.pages;
import com.apd.qa.base.TestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


	public class DynamicButtonsPage extends TestBase {
		
		/* REGION FOR WEB PAGE OBJECTS*/
		private String dynamicButton="//button[normalize-space() ='REPLACETEXT']";
		private String buttonMessageLabel="//p[@id='buttonmessage']";
		WebDriverWait wait; 
		/*END*/
		
		public DynamicButtonsPage(){
	        wait = new WebDriverWait(driver,30);
	    }

		
		/* REGION FOR WEB PAGE ACTIONS*/
		
		/**
		 * @param buttonText
		 * This action is used to click on dynamic button
		 */
		public DynamicButtonsPage clickOndynamicButton(String buttonText){			
			// explicit wait - to wait for the compose button to be click-able

			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(dynamicButton.replace("REPLACETEXT", buttonText))));
			driver.findElement(By.xpath(dynamicButton.replace("REPLACETEXT", buttonText))).click();
			return new DynamicButtonsPage();
		}
		
		/**
		 * This action is used to Get Button Message Label Text
		 */
		public String GetButtonMessageLabelText(){
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(buttonMessageLabel)));
			return driver.findElement(By.xpath(buttonMessageLabel)).getText();
		}
		/*END*/
}
	
