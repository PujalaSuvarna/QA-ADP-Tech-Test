package com.apd.qa.pages;

import com.apd.qa.base.TestBase;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class IndexPage extends TestBase {
	
	@FindBy(xpath="//a[text()[normalize-space() = 'Dynamic Buttons Challenge 01']]")
	WebElement dynamiChallengeFirstLink;
	
	@FindBy(xpath="//a[@id='calculatetest']")
	WebElement calculatorLink;
	
	public IndexPage(){
		PageFactory.initElements(driver, this);
	}
	
	
		
		/**
		 * This action is used to click on dynamic challenge first link
		 */
		public DynamicButtonsPage clickOndynamiChallengeFirstLink(){
			dynamiChallengeFirstLink.click();
			return new DynamicButtonsPage();
		}
		
		/**
		 * This action is used to click on calculator link
		 */
		public CalculatorPage clickOncalculatorLink(){
			calculatorLink.click();
			return new CalculatorPage();
		}
}
