package com.apd.qa.apibuilder;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class PostApiBuilder {
	
	public Map<String,String> defaultHeaders(){
		Map<String,String> defaultHeaders= new HashMap<String,String>();
		defaultHeaders.put("Content-Type", "application/json");
		return defaultHeaders;
	}
	
	public Map<String,String> defaultHeadersWithToken(String requesToken){
		Map<String,String> defaultHeaders= new HashMap<String,String>();
		defaultHeaders.put("Content-Type", "application/json");
		defaultHeaders.put("Acess_Token", requesToken);
		return defaultHeaders;
	}
	public Map<String,String> defaultHeadersWithAuth(String userName,String password){
		Map<String,String> defaultHeaders= new HashMap<String,String>();
		defaultHeaders.put("username", userName);
		defaultHeaders.put("password", password);
		return defaultHeaders;
	}
	
	public Map<String,Object>  newBooking(){	 
		int totalprice = (int)(Math.random()*(400-200+1)+200);
		Date today = new Date();
		Date tomorrow = new Date(today.getTime() + (1000 * 60 * 60 * 24));
		Date overorrow = new Date(today.getTime() + (1000 * 60 * 60 * 24) + (1000 * 60 * 60 * 24));
		Map<String, Object> mapBookingDates = new HashMap<String, Object>();
		mapBookingDates.put("checkin", tomorrow.toString());
		mapBookingDates.put("checkout", overorrow.toString());
		Map<String, Object> bookingBody= new HashMap<String,Object>();
		bookingBody.put("firstname", "firstname");
		bookingBody.put("lastname", "lastname");
		bookingBody.put("totalprice", Integer.toString(totalprice));
		bookingBody.put("depositpaid", "true");
		bookingBody.put("bookingdates", mapBookingDates);
		bookingBody.put("additionalneeds", "Breakfast");
		return bookingBody;
	}

}
