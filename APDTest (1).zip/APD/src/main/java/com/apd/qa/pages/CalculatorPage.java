package com.apd.qa.pages;
import com.apd.qa.base.TestBase;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CalculatorPage extends TestBase {
	
	/* REGION FOR WEB PAGE OBJECTS*/
	private String number1Textbox="//input[@id='number1']";
	private String number2Textbox="//input[@id='number2']";
	private String functionSelect="//select[@id='function']";
	private String calculateSubmit="//input[@id='calculate']";
	private String answerSpan="//span[@id='answer']";
	WebDriverWait wait;
	/*END*/
	
	
	public CalculatorPage(){
        wait = new WebDriverWait(driver,30);
    }
	
	/* REGION FOR WEB PAGE ACTIONS*/
	

	
	public void EnterTextOnFirstTextBox(String firstNum){		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(number1Textbox)));
		driver.findElement(By.xpath(number1Textbox)).sendKeys(Keys.chord(Keys.CONTROL, "a"),firstNum);
	}
	
	public void EnterTextOnSecondTextBox(String secondNum){			
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(number2Textbox)));
		driver.findElement(By.xpath(number2Textbox)).sendKeys(Keys.chord(Keys.CONTROL, "a"),secondNum);
	}
	
	public void SelectOperation(String optionType){
		Select select = new Select(driver.findElement(By.xpath(functionSelect)));
		select.selectByVisibleText(optionType);
	}
	
	public void clickOnCalculateButton(){
		driver.findElement(By.xpath(calculateSubmit)).click();
	}
	
	/**
	 * @param firstNum  First Number 
	 * @param secondNum Second Number 
	 * @param optionType Operation Type
	 * @return GetResultBasedOnFunction
	 */
	public String GetResultBasedOnFunction(String firstNum,String secondNum,String optionType){
		EnterTextOnFirstTextBox(firstNum);
		SelectOperation(optionType);
		EnterTextOnSecondTextBox(secondNum);
		clickOnCalculateButton();
		return driver.findElement(By.xpath(answerSpan)).getText();
	}
	/*END*/

}
